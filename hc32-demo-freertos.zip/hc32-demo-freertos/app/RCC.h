#ifndef RCC_HC32F460
#define RCC_HC32F460

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "hc32_ll_clk.h"
#include "hc32_ll_utility.h"
/* C binding of definitions if building with C++ compiler */
#ifdef __cplusplus
extern "C"
{
#endif
void CLK_Init(void);






#ifdef __cplusplus
}
#endif
#endif
