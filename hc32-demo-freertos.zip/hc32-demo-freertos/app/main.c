#include <main.h>
#include "FreeRTOS.h"
#include "task.h"
#include "RCC.h"


//void SysTick_Handler(void)
//{
//    SysTick_IncTick();
//	  
//	  lv_tick_inc(1);
//}

/* unlock/lock peripheral */
#define EXAMPLE_PERIPH_WE               (LL_PERIPH_GPIO | LL_PERIPH_EFM | LL_PERIPH_FCG | \
                                         LL_PERIPH_PWC_CLK_RMU | LL_PERIPH_SRAM)
#define EXAMPLE_PERIPH_WP               (LL_PERIPH_EFM | LL_PERIPH_FCG | LL_PERIPH_SRAM)

#define START_TASK_PRIO		1
//�����ջ��С	
#define START_STK_SIZE 		128  
//������
TaskHandle_t StartTask_Handler;
//������
void start_task(void *pvParameters)
{
		taskENTER_CRITICAL();
	}
int main(void)
{
//	xTaskCreate((TaskFunction_t )start_task,
//						(const char*)"start_task",
//						(uint16_t       )START_STK_SIZE,        //�����ջ��С
//            (void*          )NULL,                  //���ݸ��������Ĳ���
//            (UBaseType_t    )START_TASK_PRIO,       //�������ȼ�
//            (TaskHandle_t*  )&StartTask_Handler);
//	vTaskStartScheduler();
	/* Peripheral registers write unprotected */
	LL_PERIPH_WE(EXAMPLE_PERIPH_WE);
	
	CLK_Init();
	/* SysTick configuration */
  (void)SysTick_Init(1000U);
	
  /* Peripheral registers write protected */
  LL_PERIPH_WP(EXAMPLE_PERIPH_WP);
	while(1)
	{
	}
		
	}
