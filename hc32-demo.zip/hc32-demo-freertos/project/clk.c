
#include "clk.h"
/**
 * @brief  Clock initialize.
 *         Set board system clock to MPLL@200MHz
 * @param  None
 * @retval None
 */
 void CLK_Init(void)
 {
	 stc_clock_xtal_init_t xtal_init;
	 stc_clock_pll_init_t xtal_pll;
	 
	 CLK_XtalStructInit(&xtal_init);//deinit CLK and PLL
	 CLK_PLLStructInit(&xtal_pll);
	 
	 /* Set bus clk div. */
   CLK_SetClockDiv(CLK_BUS_CLK_ALL, (CLK_HCLK_DIV1 | CLK_EXCLK_DIV2 | CLK_PCLK0_DIV1 | CLK_PCLK1_DIV2 | \
                                      CLK_PCLK2_DIV4 | CLK_PCLK3_DIV4 | CLK_PCLK4_DIV2));
	  /* Config Xtal and enable Xtal */
    xtal_init.u8Mode = CLK_XTAL_MD_OSC;
    xtal_init.u8Drv = CLK_XTAL_DRV_ULOW;
    xtal_init.u8State = CLK_XTAL_ON;
    xtal_init.u8StableTime = CLK_XTAL_STB_2MS;
    (void)CLK_XtalInit(&xtal_init);
	 
	   /* MPLL config (XTAL / pllmDiv * plln / PllpDiv = 200M). */
    xtal_pll.PLLCFGR = 0UL;
    xtal_pll.PLLCFGR_f.PLLM = 1UL - 1UL;
    xtal_pll.PLLCFGR_f.PLLN = 50UL - 1UL;
    xtal_pll.PLLCFGR_f.PLLP = 2UL - 1UL;
    xtal_pll.PLLCFGR_f.PLLQ = 2UL - 1UL;
    xtal_pll.PLLCFGR_f.PLLR = 2UL - 1UL;
    xtal_pll.u8PLLState = CLK_PLL_ON;
    xtal_pll.PLLCFGR_f.PLLSRC = CLK_PLL_SRC_XTAL;
    (void)CLK_PLLInit(&xtal_pll);
 }
 