#ifndef __HC32F4XX_clk_H
#define __HC32F4XX_clk_H

//define
#include "hc32_ll_clk.h"
#include "hc32_ll_utility.h"
//end def

//function
 void CLK_Init(void);
//end function



#endif
